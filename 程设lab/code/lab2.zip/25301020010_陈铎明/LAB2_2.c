#include<stdio.h>

int main(){
    int a,b,c,sum,min,max;
    double average;
    printf("请输入三个整数\n");
    scanf("%d %d %d",&a,&b,&c);
    sum=a+b+c;
    average=sum/3.0;
    min=(a<b)?a:b;
    min=(min<c)?min:c;
    max=(a>b)?a:b;
    max=(max>c)?max:c;
    printf("这三个数的和为%d\n",sum);
    printf("这三个数的平均数为%.2f\n",average);
    printf("这三个数的最小值为%d\n",min);
    printf("这三个数的最大值为%d\n",max);    
    return 0;
}