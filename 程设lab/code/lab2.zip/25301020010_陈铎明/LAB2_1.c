#include <stdio.h>
#include <math.h>

int main()
{
    const double PI=3.1415926;
    double r,V;
    V=4.0/3*PI*pow(r,3);    //(1)
    double R,R1,R2;
    R=1/(1/R1+1/R2);        //(2)
    double x,y;
    y=pow(x,5)+pow(x,3)+6;  //(3)
    double F,M1,M2,R2,G;
    F=G*M1*M2/R2/R2;        //(4)
    double f;
    f=sin(x)/x+fabs(cos(PI*x/2));    //(5)
    int a,p,q;
    p=(a<10 && a>0);            //(6)
    q=(x==1)^(y==2);          //(7)
    return 0;
}
