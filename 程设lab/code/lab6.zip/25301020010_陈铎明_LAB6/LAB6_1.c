#include <stdio.h>

long long gcd(long long a, long long b)
{
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    while (b != 0) {
        long long remainder = a % b;
        a = b;
        b = remainder;
    }
    return a;
}

void print_fraction(int index, long long *num, long long *den)
{
    long long divisor = gcd(*num, *den);
    *num /= divisor;
    *den /= divisor;
    if (*den < 0) {
        *num = -*num;
        *den = -*den;
    }
    printf("%d: %lld/%lld\n", index, *num, *den);
}

int main(void)
{
    int n;
    scanf("%d", &n);
    long long sum_num = 0;
    long long sum_den = 1;
    for (int i = 0; i < n; i++) {
        long long a, b;
        scanf("%lld %lld", &a, &b);
        sum_num = sum_num * b + a * sum_den;
        sum_den *= b;
        print_fraction(i + 1, &sum_num, &sum_den);
    }
    return 0;
}
