#include<stdio.h>
//采用闭区间
int max(int a[], int left,int right){
    int middle;
    if (left==right){
        return left;
    }
    middle=left+(right-left)/2;
    int left_max=max(a,left,middle);
    int right_max=max(a,middle+1,right);
    if (a[left_max]>=a[right_max]){
        return left_max;
    }
    return right_max;
}
int main(){
    int n,i,readings[100],max_index;
    scanf("%d",&n);
    for (i=0;i<n;i++){
        scanf("%d",&readings[i]);
    }
    max_index=max(readings,0,n-1);
    printf("max: %d at %d\n",readings[max_index],max_index);
    return 0;
}