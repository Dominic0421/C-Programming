
#include <stdio.h>

int main(void)
{
    unsigned short a = 0;
    unsigned int   b = 0;
    while ((unsigned short)(a + 1) != 0) a++; 
    while (b + 1u != 0u) b++;               
    unsigned long long c = 1;
    int bits = 0;
    while (c != 0) {  
        c <<= 1;
        bits++;
    }                    
    printf("short     类型的最大整数是 %d\n",  (int)(a >> 1));
    printf("int       类型的最大整数是 %d\n",  (int)(b >> 1));
    printf("long long 类型的最大整数是 %lld\n",
           (long long)(((unsigned long long)1 << (bits - 1)) - 1));
    return 0;
}
