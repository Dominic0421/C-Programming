#include<stdio.h>

int main(){
    int a,b,c;
    printf("请输入两个整数\n");
    scanf("%d %d",&a,&b);
    c=a;
    if (b>a) c=b;
    printf("更大的整数是%d",c);
    return 0;
}