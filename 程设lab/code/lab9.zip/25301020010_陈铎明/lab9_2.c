#include<stdio.h>
void reverse(int *first, int *last){
    int t;
    while (first<last){
        t=*first;
        *first=*last;
        *last=t;
        first++;
        last--;
    }
}
void swap_blocks(int *first, int *middle, int *last){
    reverse(first,middle);
    reverse(middle+1,last);
    reverse(first,last);
}
int main(){
    int n;
    scanf("%d",&n);
    int a[n];
    for (int i=0;i<n;i++)
    scanf("%d",&a[i]);
    int l,m,r;
    scanf("%d %d %d",&l,&m,&r);
    swap_blocks(a+l,a+m,a+r);
    for (int i=0;i<n;i++)
    printf("%d ",a[i]);
    return 0;
}