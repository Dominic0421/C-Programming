#include<stdio.h>
#include<string.h>
void compress_runs(char *s, int *length){
    char *p=s,*q=s;
    int cnt=1;
    for (;*p;p++){
        if (*p==*(p+1)) cnt++;
        else if (cnt==1){
            *q=*p;
            q++;
        }else if (cnt>99){
            *q=*p;
            *(++q)=cnt/100+'0';
            *(++q)=cnt/10%10+'0';
            *(++q)=cnt%10+'0';
            q++;
            cnt=1;
        }else if (cnt>9){
            *q=*p;
            *(++q)=cnt/10+'0';
            *(++q)=cnt%10+'0';
            q++;
            cnt=1;
        }else{
            *q=*p;
            *(++q)=cnt+'0';
            q++;
            cnt=1;
        }
    }
    *q='\0';
    *length=(int)(q-s);
}
int main(){
    char s[120];
    int length;
    if (fgets(s,sizeof(s),stdin)==NULL) return 0;
    s[strcspn(s,"\r\n")]='\0';
    compress_runs(s,&length);
    printf("encoded: [%s]\n",s);
    printf("length: %d\n",length);
    return 0;
}