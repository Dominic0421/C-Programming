#include<stdio.h>
#include<math.h>

int main(){
    double sum=0;
    int i=1;
    int x=1;
    while (fabs(sum-3.14)>5e-3){
        sum+=4.0/(2*i-1)*x;
        x*=-1;
        i++;
    }
    printf("得到近似值3.14需要%d项\n",i-1);
    while (fabs(sum-3.141)>5e-4){
        sum+=4.0/(2*i-1)*x;
        x*=-1;
        i++;
    }
    printf("得到近似值3.141需要%d项\n",i-1);
    while (fabs(sum-3.1415)>5e-5){
        sum+=4.0/(2*i-1)*x;
        x*=-1;
        i++;
    }
    printf("得到近似值3.1415需要%d项\n",i-1);
    while (fabs(sum-3.14159)>5e-6){
        sum+=4.0/(2*i-1)*x;
        x*=-1;
        i++;
    }
    printf("得到近似值3.14159需要%d项\n",i-1);
    return 0;
}