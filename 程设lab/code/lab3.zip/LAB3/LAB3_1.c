#include<stdio.h>
#include<math.h>

int main(){
    double x1,x2,x3,y1,y2,y3,d1,d2,d3,max,min,mid;
    scanf("%lf %lf",&x1,&y1);
    scanf("%lf %lf",&x2,&y2);
    scanf("%lf %lf",&x3,&y3);
    d1=sqrt(pow((x1-x2),2)+pow((y1-y2),2));
    d2=sqrt(pow((x1-x3),2)+pow((y1-y3),2));
    d3=sqrt(pow((x3-x2),2)+pow((y3-y2),2));
    max=d1>d2?d1:d2;
    max=max>d3?max:d3;
    min=d1<d2?d1:d2;
    min=min<d3?min:d3;
    mid=d1+d2+d3-max-min;
    if (!min){
        printf("有点重合\n");
    }else if (fabs(((x1-x2)*(y1-y3)-(x1-x3)*(y1-y2)))<1e-6){
        printf("三点共线\n");
    }else {             //不用考虑三边关系，不存在两边之和小于第三边的情况
        if (fabs(max*max-mid*mid-min*min)<1e-6){
            printf("直角三角形\n");
        }else if(max*max-mid*mid-min*min>0){
            printf("钝角三角形\n");
        }else printf("锐角三角形\n");
        if (max-min<1e-6){
            printf("等边三角形\n");
        }else if (mid-min<1e-6||max-mid<1e-6){
            printf("等腰三角形\n");
        }
    }
    return 0;
}