#include<stdio.h>

int main(){
    int n;
    scanf("%d",&n);
    for (int i=0;i<2*n-1;i++){
        printf("*");
    }
    printf("\n");
    for (int i=1;i<n;i++){
        for (int j=0;j<i;j++){
            printf(" ");
        }
        printf("*");
        for (int k=0;k<2*n-2*i-3;k++){
            printf(" ");
        }
        if (i!=n-1) printf("*");    //最后一行可以视为两个*重合，不需要打印第二次
        for (int j=0;j<i;j++){
            printf(" ");
        }
        printf("\n");
    }
    return 0;
}