#include<stdio.h>
int find_range(int a[], int n, int key, int *first, int *last){
    int begin=0,end=n;
    int mid;
    if (key<a[0]||key>a[n-1])
    return 0;
    while (begin!=end){
        mid=(begin+end)/2;
        if (a[mid]<key){
            begin=mid+1;
        }else{
            end=mid;
        }
    }
    if (a[begin]!=key) return 0;
    *first=begin;
    begin=0;
    end=n;
    while (begin!=end){
        mid=(begin+end)/2;
        if (a[mid]<=key){
            begin=mid+1;
        }else{
            end=mid;
        }
    }
    *last=end-1;
    return 1;
}

int main(){
    int n,key,lower,upper;
    scanf("%d",&n);
    int a[n];
    for (int i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    scanf("%d",&key);
    int check=find_range(a,n,key,&lower,&upper);
    if (check){
        printf("range: %d %d\n",lower,upper);
    }else{
        printf("not found\n");
    }
}