#include<stdio.h>
int time_to_minutes(char *s, int *minutes){
    int cnt=0,hour;
    while (s[cnt]!='\0'){
        cnt++;
    }
    if (cnt==4){
        if (s[0]<'0'||s[0]>'9'||s[1]!=':'||s[2]<'0'||s[2]>'5'||s[3]<'0'||s[3]>'9')
            return 0;
        hour=s[0]-'0';
        *minutes=hour*60+(s[2]-'0')*10+s[3]-'0';
        return 1;
    }
    if (cnt==5){
        if (s[0]<'0'||s[0]>'2'||s[1]<'0'||s[1]>'9'||s[2]!=':'||s[3]<'0'||s[3]>'5'||s[4]<'0'||s[4]>'9')
        return 0;
        if (s[0]=='2'&&s[1]>'3')
        return 0;
        hour=(s[0]-'0')*10+s[1]-'0';
        *minutes=hour*60+(s[3]-'0')*10+s[4]-'0';
        return 1;
    }
    return 0;
}

int main(){
    char s[17];
    int min=-1;
    fgets(s,sizeof s,stdin);
    int i=0;
    while (s[i]!='\0'&&s[i]!='\n'){
        ++i;
    }
    if (s[i]=='\n'){
        s[i]='\0';
    }
    int check=time_to_minutes(s,&min);
    if (check){
        printf("minutes: %d\n",min);
    }else
    printf("INVALID\n");
    return 0;
}