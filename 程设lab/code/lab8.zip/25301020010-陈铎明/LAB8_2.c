#include<stdio.h>
void reverse(int *first, int *last){
    int *p=first,*q=last;
    int t;
    while(p<q){
        t=*p;
        *p=*q;
        *q=t;
        p++;
        q--;
    }
}
int main(){
    int n;
    scanf("%d",&n);
    int a[n];
    for (int i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    int l,r;
    scanf("%d %d",&l,&r);
    reverse(a+l,a+r);
    for (int i=0;i<n-1;i++){
        printf("%d ",a[i]);
    }
    printf("%d",a[n-1]);
    return 0;
}
