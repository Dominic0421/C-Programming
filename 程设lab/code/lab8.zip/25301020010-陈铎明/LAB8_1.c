#include<stdio.h>
void remove_char(char *s,char c){
    char *a,*b;
    for (a=s,b=s;*a;a++){
        if (*a==c) continue;
        *b++=*a;
    }
    *b='\0';
}

int my_strcmp( const char *a, const char *b){
    while(*a||*b){
        if (*a>*b) return 1;
        if (*a<*b) return -1;
        a++;
        b++;
    }
    return 0;
}

int main(){
    char s[60],c,t[60];
    scanf("%s",s);
    scanf(" %c",&c);
    remove_char(s,c);
    scanf("%s",t);
    if (*s)printf("cleaned: %s\n",s);
    else printf("cleaned: EMPTY\n");
    int check=my_strcmp(s,t);
    printf("cmp: %d\n",check);
    return 0;
}
