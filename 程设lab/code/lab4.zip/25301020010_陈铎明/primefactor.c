#include<stdio.h>
#include<math.h>
int main(){
    int n,j=0,m;
    scanf("%d",&n);
    int a[n]={0};
    m=n;
    for (int i=2;i<=sqrt(m);i++){
        if (n%i==0){
            a[j]=i;
            j++;
            n=n/i;
            i=1;
            }
    }
    if (!j) printf("%d=%d",m,m);
    else {
        printf("%d=%d",m,a[0]);
        for (int k=1;k<j;k++){
            printf("*%d",a[k]);
        }
        if (n>1) printf("*%d",n);
    }
    return 0;
}