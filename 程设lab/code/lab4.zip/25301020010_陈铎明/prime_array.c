#include<stdio.h>
int main(){
    int n=1000000;
    char prime[n];
    prime[0]=prime[1]=0;
    for (int i=2;i<n;i++){
        prime[i]=1;
    }
    for (int i=2;i*i<n;i++){
        if (prime[i]) {
            for (int j=i;j*i<n;j++){
                prime[j*i]=0;
        }
            
        }
   }
    int cnt=0;
    for (int j=2;j<n;j++){
        if (prime[j]) cnt++;
    }
    printf("%d",cnt);
    return 0;
}