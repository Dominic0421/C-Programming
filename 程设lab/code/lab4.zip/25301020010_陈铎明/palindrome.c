#include<stdio.h>
#include<math.h>
int main(){
    int a,t,sum=0,i,w=0;
    scanf("%d",&a);
    if (a<=0) printf("请输入正整数");
    else{
        t=a;
        while (t/10>0){
        t=t/10;
        w++;
        }
        t=a;
        for (int i=w;i>=0;i--){
            sum+=t%10*pow(10,i);
            t/=10;
        }
        if (a==sum) printf("是回文数");
        else printf("不是回文数");
    }
    return 0;
}