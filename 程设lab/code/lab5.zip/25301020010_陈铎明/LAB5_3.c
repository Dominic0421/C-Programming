#include<stdio.h>

void swap(int *a,int *b){
    int t=*a;
    *a=*b;
    *b=t;
}
int main(){
    int n,k,j;
    scanf("%d",&n);
    int a[n];
    for (int i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    int end=n-1;
    while (end){
        for (k=j=0;j<end;j++)
            if (a[j]>a[j+1])
                {swap (&a[j],&a[j+1]);k=j;}
        end=k;
    }
    for (int i=0;i<n;i++) printf("%d ",a[i]);
    return 0;
}