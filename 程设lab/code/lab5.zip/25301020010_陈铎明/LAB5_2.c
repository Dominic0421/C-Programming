#include<stdio.h>
int main(){
    int n;
    scanf("%d",&n);
    int num1[n];
    for (int i=0;i<n;i++){
        scanf("%d",&num1[i]);
    }
    int num2[n],j=1;
    num2[0]=num1[0];
    for (int i=1;i<n;i++){
        int check=1;
        for (int k=0;k<j;k++){
            if (num1[i]==num2[k]) {check=0;break;}
        }
        if (check) {num2[j]=num1[i];j++;}
        }
    for (int k=0;k<j;k++){
            printf("%d ",num2[k]);
        }
        return 0;
}