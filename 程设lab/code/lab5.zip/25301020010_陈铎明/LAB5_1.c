#include<stdio.h>
int main(){
    int a,n,w,sum=0,base=1;
    scanf("%d %d",&a,&n);
    w=a;
    for (int x = a; x > 0; x /= 10) {
        base *= 10;
    }
    for (int i=0;i<n;i++){
        sum+=a;
        a=a*base+w;
    }
    printf("%d",sum);
    return 0;
}