#!/bin/bash
# macOS / Linux; Bash 3.2 or later. Run an already compiled program.
set -u
if [ "$#" -lt 2 ] || [ "$#" -gt 3 ]; then
    echo '用法: bash selftest/check.sh lab10_1 ./lab10_1 [单例超时秒数，默认5]' >&2
    exit 2
fi
task="$1"
exe_arg="$2"
limit="${3:-5}"
case "$limit" in ''|*[!0-9]*|0) echo '超时秒数须为正整数。' >&2; exit 2;; esac
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd) || exit 2
if [ ! -f "$exe_arg" ] || [ ! -x "$exe_arg" ]; then
    echo "找不到可执行程序或没有执行权限: ${exe_arg}。请先编译。" >&2
    exit 2
fi
exe_dir=$(CDPATH= cd -- "$(dirname -- "$exe_arg")" && pwd) || exit 2
exe="$exe_dir/$(basename -- "$exe_arg")"
manifest="$root/cases.tsv"
if [ ! -f "$manifest" ]; then echo '缺少cases.tsv，请完整解压自测目录。' >&2; exit 2; fi
work=$(mktemp -d "${TMPDIR:-/tmp}/lab-check.XXXXXX") || exit 2
passed=0
failed=0
total=0
child=''
guard=''
cleanup() {
    if [ -n "$child" ]; then kill "$child" 2>/dev/null || :; fi
    if [ -n "$guard" ]; then kill "$guard" 2>/dev/null || :; fi
    if [ "$failed" -eq 0 ]; then rm -rf -- "$work"; fi
}
trap cleanup EXIT
trap 'failed=1; exit 130' INT TERM
normalize() {
    LC_ALL=C awk '{ sub(/\r$/, ""); sub(/[ \t]+$/, ""); print }' "$1" > "$2"
}
while IFS=$'\t' read -r item name expected || [ -n "$item" ]; do
    [ "$item" = "$task" ] || continue
    case "$name" in ''|*[!A-Za-z0-9_-]*) echo '用例名称无效。' >&2; failed=1; exit 2;; esac
    case "$expected" in ''|*[!0-9]*) echo '用例退出码无效。' >&2; failed=1; exit 2;; esac
    total=$((total + 1))
    fixture="$root/$task/$name"
    run="$work/$name"
    mkdir -p -- "$run" || exit 2
    input="$fixture/input.txt"
    if [ ! -f "$input" ] || [ ! -f "$fixture/expected_stdout.txt" ]; then
        echo "缺少用例文件: $fixture" >&2; failed=1; exit 2
    fi
    (cd -- "$run" && exec "$exe" < "$input" > actual_stdout.txt 2> actual_stderr.txt) &
    child=$!
    (
        sleep "$limit" & sleeper=$!
        trap 'kill "$sleeper" 2>/dev/null; exit 0' TERM INT
        wait "$sleeper" 2>/dev/null
        if kill -0 "$child" 2>/dev/null; then
            : > "$run/timed_out"
            kill -TERM "$child" 2>/dev/null || :
            sleep 1
            kill -KILL "$child" 2>/dev/null || :
        fi
    ) 2>/dev/null &
    guard=$!
    wait "$child" 2>/dev/null
    code=$?
    child=''
    kill "$guard" 2>/dev/null || :
    wait "$guard" 2>/dev/null || :
    guard=''
    reason=''
    if [ -f "$run/timed_out" ]; then reason="$reason 超时;"; fi
    if [ "$code" -ne "$expected" ]; then reason="$reason 退出码$code(预期$expected);"; fi
    if [ -s "$run/actual_stderr.txt" ]; then reason="$reason 存在错误输出;"; fi
    normalize "$fixture/expected_stdout.txt" "$run/expected_normalized.txt"
    normalize "$run/actual_stdout.txt" "$run/actual_normalized.txt"
    if ! cmp -s "$run/expected_normalized.txt" "$run/actual_normalized.txt"; then
        reason="$reason 终端输出不符;"
        diff -u "$run/expected_normalized.txt" "$run/actual_normalized.txt" > "$run/stdout.diff" || :
    fi
    if [ -z "$reason" ]; then
        passed=$((passed + 1)); echo "$name: PASS"
    else
        failed=$((failed + 1)); echo "$name: FAIL，$reason"
        echo "  输入与期望: $fixture"
        echo "  实际结果: $run"
    fi
done < "$manifest"
if [ "$total" -eq 0 ]; then echo "没有程序 $task 的用例，请检查题号。" >&2; exit 2; fi
echo "$passed/$total 通过。自测可选，通过率不直接计分。"
if [ "$failed" -ne 0 ]; then echo "失败结果已保留: $work"; exit 1; fi
exit 0
