# LAB10 可选自测说明

这里有两题各50组、共100组公开用例。自测只提供反馈，不直接计分；无需运行全部用例、提交日志或修改脚本。报告每题给出三组测试，每组包含输入、预期输出和实际输出，来源和呈现形式不限。你也可以完全手工测试。

## 目录与文件

完整解压后，从存放 `lab10_1.c`、`lab10_2.c` 和“selftest”文件夹的LAB10目录运行命令。不要在ZIP预览中运行，不要进入用例子目录运行整套测试。

```text
LAB10/
├── lab10_1.c          你编写的源码
├── lab10_2.c          你编写的源码
└── selftest/
    ├── README.md
    ├── check.ps1     Windows PowerShell
    ├── check.sh      macOS或Linux Bash
    ├── cases.tsv     脚本读取的清单，请保留
    ├── case_index.md  可查看各用例说明
    ├── lab10_1/       任务1的50组用例
    └── lab10_2/       任务2的50组用例
```

脚本接收“程序题号”和“已编译程序路径”两个参数，不替你编译。每次改动源码后先重新编译，确认编译成功，避免运行上一次的旧程序。

## Windows 使用PowerShell

### 1 打开LAB10目录

在文件资源管理器中打开LAB10文件夹，在地址栏输入 `powershell` 并回车。也可在已有PowerShell中用 `cd "你的LAB10完整路径"` 进入。下面命令要输入PowerShell，不能输入C程序窗口。

### 2 编译两题

若gcc已经可用：

```text
gcc -std=c11 -Wall -Wextra .\lab10_1.c -o .\lab10_1.exe
gcc -std=c11 -Wall -Wextra .\lab10_2.c -o .\lab10_2.exe
```

若通过IDE编译，继续用原方法。找到生成的exe实际位置即可，不必重新安装或配置gcc。

### 3 分别运行

```text
.\selftest\check.ps1 lab10_1 .\lab10_1.exe
.\selftest\check.ps1 lab10_2 .\lab10_2.exe
```

如果exe在别处，填写完整路径并加双引号，例如：

```text
.\selftest\check.ps1 lab10_1 "C:\我的作业\build\lab10_1.exe"
```

### 若提示禁止运行脚本

确认使用的是课程发放脚本后，可用以下单次命令。它不永久修改系统执行策略：

```text
powershell -NoProfile -ExecutionPolicy Bypass -File ".\selftest\check.ps1" lab10_1 ".\lab10_1.exe"
```

第二题替换为lab10_2与对应exe。若公共机房策略仍禁止执行脚本，但程序本身可以运行，采用手工自测即可。若程序也无法运行，联系助教或使用课程提供的可运行环境。

### 若提示“应用程序控制策略已阻止此文件”

如果本机策略阻止运行编译出的程序，请联系助教，或在课程提供的环境中编译并运行。报告也可以记录手工测试结果。

## macOS或Linux 使用终端

### 1 进入LAB10目录

打开终端，执行 `cd "你的LAB10完整路径"`。路径含空格时保留引号。

### 2 编译两题

```text
cc -std=c11 -Wall -Wextra lab10_1.c -o lab10_1
cc -std=c11 -Wall -Wextra lab10_2.c -o lab10_2
```

cc也可换成平时使用的gcc或clang。使用IDE时，直接找到本机生成的可执行程序。

### 3 分别运行

```text
bash selftest/check.sh lab10_1 ./lab10_1
bash selftest/check.sh lab10_2 ./lab10_2
```

路径含空格时使用引号，例如 `bash selftest/check.sh lab10_1 "/你的路径/我的作业/lab10_1"`。用bash调用脚本，无需给check.sh设置执行权限。不能在macOS上直接运行Windows的exe。

## 如何查看结果

```text
sample: PASS
combination_01: PASS
combination_02: FAIL，终端输出不符
...
49/50 通过。自测可选，通过率不直接计分。
```

- PASS表示这一例通过；FAIL后面给出原因。先从第一条失败用例开始检查，无需反复跑全部用例。
- “输入与期望”是该用例文件夹。打开input.txt看输入，expected_stdout.txt看预期。
- “实际结果”是本次运行的临时目录。actual_stdout.txt保存程序输出，actual_stderr.txt保存错误信息。Bash入口还会生成stdout.diff，标明文本差异。
- 失败日志保留在系统临时目录；需要长期保留时复制出来。全部通过后临时结果自动清理。脚本不会覆盖你的源码和报告。

默认单例最多5秒，超时通常意味着多读输入或循环未结束。需要延长时在命令末尾加15，例如 `bash selftest/check.sh lab10_1 ./lab10_1 15`，PowerShell同样可加15。不要在整套自测中停在调试断点；改为手工调试单例。

比较忽略Windows/macOS换行区别、行尾空格或制表符及末行换行。数值、大小写、标点、行首和内部空格仍按输出规范比较。脚本只核对运行结果。整行读入、逐字符查找函数及结构体字段的使用，以源码为准。

脚本退出码：0表示全部通过，1表示至少一例失败，2表示路径、参数或用例文件有问题。自动测试通过率不直接折算成绩，全部PASS也不证明所有输入都正确。

## 手工测试

打开某个用例的input.txt，将内容按行复制到你的程序运行窗口，再与expected_stdout.txt比较。可从两题各自的sample目录开始。每组输入都应重新运行一次程序。

macOS/Linux也可用输入重定向：

```text
./lab10_1 < selftest/lab10_1/sample/input.txt
./lab10_2 < selftest/lab10_2/sample/input.txt
```

报告每题给出三组测试，每组包含输入、预期输出和实际输出；来源和呈现形式不限。使用公开用例时可附程序名和用例名以便定位。

## 常见问题

| 现象 | 怎么处理 |
| --- | --- |
| 找不到gcc或cc | 用平时的IDE编译，向脚本传入生成程序的实际路径。 |
| 找不到check或cases.tsv | 完整解压并保持自测文件夹结构，从LAB10目录执行命令。 |
| 找不到程序或没有执行权限 | 先确认编译成功，传入生成的程序，不要传.c源码；Windows通常带.exe。 |
| 提示“应用程序控制策略已阻止此文件” | 见上文同名排障一节；调整后先手工运行样例。公共机房或仍无法运行时联系助教。 |
| 结果还是旧的 | 修改后重新编译，并确认命令指向刚生成的程序。 |
| 全部失败 | 检查题号是否与程序对应，是否额外打印提示语，是否漏读数据。 |
| 超时 | 检查是否等待题面未提供的输入、循环是否结束、扫描位置是否前进。 |

[返回LAB10开始页](../README.md)
