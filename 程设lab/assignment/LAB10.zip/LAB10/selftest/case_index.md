# LAB10 公开用例索引

每题 50 组。每个用例目录含 `input.txt` 和 `expected_stdout.txt`。

## 任务1 忽略大小写的子串查找

| 用例 | 检查内容 |
| --- | --- |
| `sample` | 题面样例，大小写与重叠 |
| `empty_text` | 空文本 |
| `pattern_longer` | 待查找串长于文本 |
| `equal_length` | 等长匹配 |
| `same_length_mismatch` | 等长但末字符不同 |
| `right_boundary` | 匹配恰好到文本末尾 |
| `overlap` | 连续重叠匹配 |
| `spaces_inside` | 空格参与匹配且匹配重叠 |
| `edge_spaces` | 文本和待查找串含行首、行末空格 |
| `only_spaces` | 两行都只由空格构成 |
| `single_char` | 单字符有多处匹配，首个下标非零 |
| `no_final_newline` | 第二行末尾无换行 |
| `max_crlf` | 两行达到长度上限，使用 CRLF |
| `max_overlap` | 最大长度文本存在大量重叠匹配 |
| `alphabet_edges` | 匹配字母 A、Z 和对应小写 |
| `combination_01` 至 `combination_35` | 多组长度、边界和操作组合 |

## 任务2 器材借还记录模拟

| 用例 | 检查内容 |
| --- | --- |
| `sample` | 题面样例，库存恰好到达上下界 |
| `no_operations` | 没有操作时输出为空 |
| `exact_empty` | 刚好借空 |
| `exact_full` | 刚好归还至满 |
| `from_empty` | 空库存借出失败后可以归还 |
| `from_full` | 满库存归还失败后可以借出 |
| `over_capacity` | 操作数量大于容量，拒绝后可继续 |
| `repeated_rejects` | 连续拒绝后小额操作仍可受理 |
| `all_accepted` | 连续接受并累计库存 |
| `all_rejected` | 多次拒绝后库存始终不变 |
| `smallest_capacity` | 最小容量及操作顺序 |
| `max_values` | 容量与数量达到上限 |
| `max_commands` | 达到 100 条操作 |
| `combination_01` 至 `combination_37` | 多组长度、边界和操作组合 |

[返回自测说明](README.md)
