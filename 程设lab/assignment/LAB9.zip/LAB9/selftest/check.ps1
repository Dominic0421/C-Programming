﻿# Windows PowerShell 5.1 / PowerShell 7. Run an already compiled program.
param(
    [Parameter(Mandatory=$true, Position=0)][string]$Task,
    [Parameter(Mandatory=$true, Position=1)][string]$Executable,
    [Parameter(Position=2)][ValidateRange(1,3600)][int]$TimeoutSeconds=5
)
$ErrorActionPreference = 'Stop'
function Normalize-Text([string]$Text) {
    $result = $Text.Replace("`r`n", "`n")
    $result = [regex]::Replace($result, '[ \t]+(?=\n|$)', '')
    if ($result.Length -gt 0 -and -not $result.EndsWith("`n")) { $result += "`n" }
    return $result
}
function Same-Bytes([string]$Left, [string]$Right) {
    if (-not [IO.File]::Exists($Left) -or -not [IO.File]::Exists($Right)) { return $false }
    $a = [IO.File]::ReadAllBytes($Left)
    $b = [IO.File]::ReadAllBytes($Right)
    if ($a.Length -ne $b.Length) { return $false }
    for ($i=0; $i -lt $a.Length; $i++) { if ($a[$i] -ne $b[$i]) { return $false } }
    return $true
}
$work = $null
$failedCount = 0
try {
    $exe = (Resolve-Path -LiteralPath $Executable).ProviderPath
    if (-not [IO.File]::Exists($exe)) { throw '找不到可执行程序，请先编译。' }
    $cases = @(Import-Csv -LiteralPath (Join-Path $PSScriptRoot 'cases.tsv') -Delimiter "`t" -Encoding UTF8 | Where-Object { $_.task -eq $Task })
    if ($cases.Count -eq 0) { throw "没有程序 $Task 的用例，请检查题号。" }
    $work = Join-Path ([IO.Path]::GetTempPath()) ('lab-check-' + [Guid]::NewGuid().ToString('N'))
    [void][IO.Directory]::CreateDirectory($work)
    $passedCount = 0
    foreach ($case in $cases) {
        if ($case.name -notmatch '^[A-Za-z0-9_-]+$') { throw '用例名称无效。' }
        $fixture = Join-Path (Join-Path $PSScriptRoot $Task) $case.name
        $run = Join-Path $work $case.name
        [void][IO.Directory]::CreateDirectory($run)
        $expected = [IO.File]::ReadAllText((Join-Path $fixture 'expected_stdout.txt'))
        if ($Task -eq 'lab10_1') {
            Copy-Item -LiteralPath (Join-Path $fixture 'measurements.txt') -Destination (Join-Path $run 'measurements.txt')
            $inputBytes = [byte[]]@()
        } else {
            $inputBytes = [IO.File]::ReadAllBytes((Join-Path $fixture 'input.txt'))
        }
        $process = New-Object System.Diagnostics.Process
        $process.StartInfo.FileName = $exe
        $process.StartInfo.WorkingDirectory = $run
        $process.StartInfo.UseShellExecute = $false
        $process.StartInfo.CreateNoWindow = $true
        $process.StartInfo.RedirectStandardInput = $true
        $process.StartInfo.RedirectStandardOutput = $true
        $process.StartInfo.RedirectStandardError = $true
        $reasons = New-Object 'System.Collections.Generic.List[string]'
        try {
            [void]$process.Start()
            $outTask = $process.StandardOutput.ReadToEndAsync()
            $errTask = $process.StandardError.ReadToEndAsync()
            $process.StandardInput.BaseStream.Write($inputBytes, 0, $inputBytes.Length)
            $process.StandardInput.Close()
            if (-not $process.WaitForExit($TimeoutSeconds * 1000)) {
                $reasons.Add('超时')
                $process.Kill()
                $process.WaitForExit()
            }
            $actual = $outTask.GetAwaiter().GetResult()
            $stderr = $errTask.GetAwaiter().GetResult()
            [IO.File]::WriteAllText((Join-Path $run 'actual_stdout.txt'), $actual)
            [IO.File]::WriteAllText((Join-Path $run 'actual_stderr.txt'), $stderr)
            if ($process.ExitCode -ne [int]$case.exit) { $reasons.Add("退出码$($process.ExitCode)(预期$($case.exit))") }
            if ($stderr.Length -gt 0) { $reasons.Add('存在错误输出') }
            if ((Normalize-Text $actual) -cne (Normalize-Text $expected)) { $reasons.Add('终端输出不符') }
            if ($Task -eq 'lab10_1') {
                $report = Join-Path $run 'summary.txt'
                if (-not [IO.File]::Exists($report)) { $reasons.Add('未生成summary.txt') }
                elseif ((Normalize-Text ([IO.File]::ReadAllText($report))) -cne (Normalize-Text ([IO.File]::ReadAllText((Join-Path $fixture 'expected_summary.txt'))))) {
                    $reasons.Add('summary.txt不符')
                }
                if (-not (Same-Bytes (Join-Path $fixture 'measurements.txt') (Join-Path $run 'measurements.txt'))) { $reasons.Add('输入文件被改变') }
            }
        } catch {
            $reasons.Add('运行失败: ' + $_.Exception.Message)
        } finally {
            try { if ($process.Id -and -not $process.HasExited) { $process.Kill(); $process.WaitForExit() } } catch { }
            $process.Dispose()
        }
        if ($reasons.Count -eq 0) {
            $passedCount++
            Write-Host "$($case.name): PASS"
        } else {
            $failedCount++
            Write-Host "$($case.name): FAIL，$($reasons -join '；')"
            Write-Host "  输入与期望: $fixture"
            Write-Host "  实际结果: $run"
        }
    }
    Write-Host "$passedCount/$($cases.Count) 通过。自测可选，通过率不直接计分。"
    if ($failedCount -gt 0) { Write-Host "失败结果已保留: $work"; exit 1 }
    exit 0
} catch {
    $failedCount++
    Write-Host ('无法开始自测: ' + $_.Exception.Message)
    Write-Host '用法: .\selftest\check.ps1 lab9_1 .\lab9_1.exe'
    if ($work) { Write-Host "已产生的结果保留在: $work" }
    exit 2
} finally {
    if ($work -and $failedCount -eq 0) { Remove-Item -LiteralPath $work -Recurse -Force }
}
