# LAB9 公开用例索引

共100组；任选即可，不要求全部运行。每个文件夹都是一次独立运行。用例名仅为标识，说明列描述本次题目下的内容。

| 程序 | 用例 | 说明 |
| --- | --- | --- |
| lab9_1 | [sample](lab9_1/sample/input.txt) | 题面样例 |
| lab9_1 | [single](lab9_1/single/input.txt) | 单字符，省略段长 1 |
| lab9_1 | [ties](lab9_1/ties/input.txt) | 区分大小写，非相邻的重复字符分段处理 |
| lab9_2 | [sample](lab9_2/sample/input.txt) | 题面样例 |
| lab9_2 | [edge](lab9_2/edge/input.txt) | 100 个元素，向后交换首个元素与其余元素 |
| lab9_2 | [contained](lab9_2/contained/input.txt) | 交换两个不等长的内部区间 |
| lab9_1 | [all_zero](lab9_1/all_zero/input.txt) | 整行同一字符，末段长度为 10 |
| lab9_1 | [maximum_name](lab9_1/maximum_name/input.txt) | 119 个相同字符，三位数段长 |
| lab9_2 | [touch_point](lab9_2/touch_point/input.txt) | 首段从数组开头起，含零和重复值 |
| lab9_2 | [opposite_corners](lab9_2/opposite_corners/input.txt) | 交换数组末尾两个单元素区间 |
| lab9_2 | [equal](lab9_2/equal/input.txt) | 两段都只有一个元素，且值相同 |
| lab9_2 | [negative](lab9_2/negative/input.txt) | 交换覆盖整个数组，元素均为负数 |
| lab9_2 | [gap](lab9_2/gap/input.txt) | 两段等长，元素取到数值上下界 |
| lab9_1 | [combination_01](lab9_1/combination_01/input.txt) | 空行，压缩后长度为 0 |
| lab9_1 | [combination_02](lab9_1/combination_02/input.txt) | 相邻字符均不同，分隔开的重复字符不合并 |
| lab9_1 | [combination_03](lab9_1/combination_03/input.txt) | 相邻两段长度分别为 9 和 10 |
| lab9_1 | [combination_04](lab9_1/combination_04/input.txt) | 99 个相同字符后跟单字符 |
| lab9_1 | [combination_05](lab9_1/combination_05/input.txt) | 100 个相同字符后跟单字符 |
| lab9_1 | [combination_06](lab9_1/combination_06/input.txt) | 长度上限，每段都只有一个字符 |
| lab9_1 | [combination_07](lab9_1/combination_07/input.txt) | 每段恰有两个字符，写入位置紧跟扫描位置 |
| lab9_1 | [combination_08](lab9_1/combination_08/input.txt) | 三位数段长位于两个单字符之间 |
| lab9_1 | [combination_09](lab9_1/combination_09/input.txt) | 随机组合 09 |
| lab9_1 | [combination_10](lab9_1/combination_10/input.txt) | 随机组合 10 |
| lab9_1 | [combination_11](lab9_1/combination_11/input.txt) | 随机组合 11 |
| lab9_1 | [combination_12](lab9_1/combination_12/input.txt) | 随机组合 12 |
| lab9_1 | [combination_13](lab9_1/combination_13/input.txt) | 随机组合 13 |
| lab9_1 | [combination_14](lab9_1/combination_14/input.txt) | 随机组合 14 |
| lab9_1 | [combination_15](lab9_1/combination_15/input.txt) | 随机组合 15 |
| lab9_1 | [combination_16](lab9_1/combination_16/input.txt) | 随机组合 16 |
| lab9_1 | [combination_17](lab9_1/combination_17/input.txt) | 随机组合 17 |
| lab9_1 | [combination_18](lab9_1/combination_18/input.txt) | 随机组合 18 |
| lab9_1 | [combination_19](lab9_1/combination_19/input.txt) | 随机组合 19 |
| lab9_1 | [combination_20](lab9_1/combination_20/input.txt) | 随机组合 20 |
| lab9_1 | [combination_21](lab9_1/combination_21/input.txt) | 随机组合 21 |
| lab9_1 | [combination_22](lab9_1/combination_22/input.txt) | 随机组合 22 |
| lab9_1 | [combination_23](lab9_1/combination_23/input.txt) | 随机组合 23 |
| lab9_1 | [combination_24](lab9_1/combination_24/input.txt) | 随机组合 24 |
| lab9_1 | [combination_25](lab9_1/combination_25/input.txt) | 随机组合 25 |
| lab9_1 | [combination_26](lab9_1/combination_26/input.txt) | 随机组合 26 |
| lab9_1 | [combination_27](lab9_1/combination_27/input.txt) | 随机组合 27 |
| lab9_1 | [combination_28](lab9_1/combination_28/input.txt) | 随机组合 28 |
| lab9_1 | [combination_29](lab9_1/combination_29/input.txt) | 随机组合 29 |
| lab9_1 | [combination_30](lab9_1/combination_30/input.txt) | 随机组合 30 |
| lab9_1 | [combination_31](lab9_1/combination_31/input.txt) | 随机组合 31 |
| lab9_1 | [combination_32](lab9_1/combination_32/input.txt) | 随机组合 32 |
| lab9_1 | [combination_33](lab9_1/combination_33/input.txt) | 随机组合 33 |
| lab9_1 | [combination_34](lab9_1/combination_34/input.txt) | 随机组合 34 |
| lab9_1 | [combination_35](lab9_1/combination_35/input.txt) | 随机组合 35 |
| lab9_1 | [combination_36](lab9_1/combination_36/input.txt) | 随机组合 36 |
| lab9_1 | [combination_37](lab9_1/combination_37/input.txt) | 随机组合 37 |
| lab9_1 | [combination_38](lab9_1/combination_38/input.txt) | 随机组合 38 |
| lab9_1 | [combination_39](lab9_1/combination_39/input.txt) | 随机组合 39 |
| lab9_1 | [combination_40](lab9_1/combination_40/input.txt) | 随机组合 40 |
| lab9_1 | [combination_41](lab9_1/combination_41/input.txt) | 随机组合 41 |
| lab9_1 | [combination_42](lab9_1/combination_42/input.txt) | 随机组合 42 |
| lab9_1 | [combination_43](lab9_1/combination_43/input.txt) | 随机组合 43 |
| lab9_1 | [combination_44](lab9_1/combination_44/input.txt) | 随机组合 44 |
| lab9_1 | [combination_45](lab9_1/combination_45/input.txt) | 随机组合 45 |
| lab9_2 | [combination_01](lab9_2/combination_01/input.txt) | 随机组合 01 |
| lab9_2 | [combination_02](lab9_2/combination_02/input.txt) | 随机组合 02 |
| lab9_2 | [combination_03](lab9_2/combination_03/input.txt) | 随机组合 03 |
| lab9_2 | [combination_04](lab9_2/combination_04/input.txt) | 随机组合 04 |
| lab9_2 | [combination_05](lab9_2/combination_05/input.txt) | 随机组合 05 |
| lab9_2 | [combination_06](lab9_2/combination_06/input.txt) | 随机组合 06 |
| lab9_2 | [combination_07](lab9_2/combination_07/input.txt) | 随机组合 07 |
| lab9_2 | [combination_08](lab9_2/combination_08/input.txt) | 随机组合 08 |
| lab9_2 | [combination_09](lab9_2/combination_09/input.txt) | 随机组合 09 |
| lab9_2 | [combination_10](lab9_2/combination_10/input.txt) | 随机组合 10 |
| lab9_2 | [combination_11](lab9_2/combination_11/input.txt) | 随机组合 11 |
| lab9_2 | [combination_12](lab9_2/combination_12/input.txt) | 随机组合 12 |
| lab9_2 | [combination_13](lab9_2/combination_13/input.txt) | 随机组合 13 |
| lab9_2 | [combination_14](lab9_2/combination_14/input.txt) | 随机组合 14 |
| lab9_2 | [combination_15](lab9_2/combination_15/input.txt) | 随机组合 15 |
| lab9_2 | [combination_16](lab9_2/combination_16/input.txt) | 随机组合 16 |
| lab9_2 | [combination_17](lab9_2/combination_17/input.txt) | 随机组合 17 |
| lab9_2 | [combination_18](lab9_2/combination_18/input.txt) | 随机组合 18 |
| lab9_2 | [combination_19](lab9_2/combination_19/input.txt) | 随机组合 19 |
| lab9_2 | [combination_20](lab9_2/combination_20/input.txt) | 随机组合 20 |
| lab9_2 | [combination_21](lab9_2/combination_21/input.txt) | 随机组合 21 |
| lab9_2 | [combination_22](lab9_2/combination_22/input.txt) | 随机组合 22 |
| lab9_2 | [combination_23](lab9_2/combination_23/input.txt) | 随机组合 23 |
| lab9_2 | [combination_24](lab9_2/combination_24/input.txt) | 随机组合 24 |
| lab9_2 | [combination_25](lab9_2/combination_25/input.txt) | 随机组合 25 |
| lab9_2 | [combination_26](lab9_2/combination_26/input.txt) | 随机组合 26 |
| lab9_2 | [combination_27](lab9_2/combination_27/input.txt) | 随机组合 27 |
| lab9_2 | [combination_28](lab9_2/combination_28/input.txt) | 随机组合 28 |
| lab9_2 | [combination_29](lab9_2/combination_29/input.txt) | 随机组合 29 |
| lab9_2 | [combination_30](lab9_2/combination_30/input.txt) | 随机组合 30 |
| lab9_2 | [combination_31](lab9_2/combination_31/input.txt) | 随机组合 31 |
| lab9_2 | [combination_32](lab9_2/combination_32/input.txt) | 随机组合 32 |
| lab9_2 | [combination_33](lab9_2/combination_33/input.txt) | 随机组合 33 |
| lab9_2 | [combination_34](lab9_2/combination_34/input.txt) | 随机组合 34 |
| lab9_2 | [combination_35](lab9_2/combination_35/input.txt) | 随机组合 35 |
| lab9_2 | [combination_36](lab9_2/combination_36/input.txt) | 随机组合 36 |
| lab9_2 | [combination_37](lab9_2/combination_37/input.txt) | 随机组合 37 |
| lab9_2 | [combination_38](lab9_2/combination_38/input.txt) | 随机组合 38 |
| lab9_2 | [combination_39](lab9_2/combination_39/input.txt) | 随机组合 39 |
| lab9_2 | [combination_40](lab9_2/combination_40/input.txt) | 随机组合 40 |
| lab9_2 | [combination_41](lab9_2/combination_41/input.txt) | 随机组合 41 |
| lab9_2 | [combination_42](lab9_2/combination_42/input.txt) | 随机组合 42 |
