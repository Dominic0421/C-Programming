# lab9_2 可选自测

本目录包含50组公开用例；每个子文件夹对应一次独立运行。先阅读[完整操作说明](../README.md)，从LAB9目录编译并调用脚本：

Windows PowerShell：

```text
gcc -std=c11 -Wall -Wextra .\lab9_2.c -o .\lab9_2.exe
.\selftest\check.ps1 lab9_2 .\lab9_2.exe
```

macOS/Linux：

```text
cc -std=c11 -Wall -Wextra lab9_2.c -o lab9_2
bash selftest/check.sh lab9_2 ./lab9_2
```

使用IDE时，将程序路径换成实际生成的可执行文件位置即可。input.txt为输入；expected_stdout.txt为预期终端输出。可以直接打开文本进行手工核对。报告可引用“lab9_2/sample”等用例编号。

可从 `sample`（不等长区间）、`contained`（两侧保留元素）和 `opposite_corners`（两段均为单元素）开始核对。

脚本只核对可见运行结果，无法全面判断题面中的源码方法要求。无需运行全部用例或提交日志，通过率不直接计分。
