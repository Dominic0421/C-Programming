# lab6_1 自测

本目录50组用例。先打开[完整操作说明](../README.md)，从LAB6根目录执行以下命令。

## Windows PowerShell

```text
.\selftest\check.ps1 lab6_1 .\lab6_1.exe
```

## macOS或Linux

```text
bash selftest/check.sh lab6_1 ./lab6_1
```

请先编译。各用例目录中的input.txt和expected_stdout.txt可以直接手工核对，不要求全部运行。
