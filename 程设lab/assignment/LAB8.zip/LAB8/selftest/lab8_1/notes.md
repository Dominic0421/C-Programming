# lab8_1 可选自测

本目录包含50组公开用例；每个子文件夹对应一次独立运行。先阅读[完整操作说明](../README.md)，从LAB8目录编译并调用脚本：

Windows PowerShell：

```text
gcc -std=c11 -Wall -Wextra .\lab8_1.c -o .\lab8_1.exe
.\selftest\check.ps1 lab8_1 .\lab8_1.exe
```

macOS/Linux：

```text
cc -std=c11 -Wall -Wextra lab8_1.c -o lab8_1
bash selftest/check.sh lab8_1 ./lab8_1
```

使用IDE时，将程序路径换成实际生成的可执行文件位置即可。input.txt为输入；expected_stdout.txt为预期终端输出。可以直接打开文本进行手工核对。报告可引用“lab8_1/sample”等用例编号。

脚本只核对可见运行结果，无法全面判断题面中的源码方法要求。无需运行全部用例或提交日志，通过率不直接计分。
