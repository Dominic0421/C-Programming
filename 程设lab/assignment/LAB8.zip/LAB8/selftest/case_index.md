# LAB8 公开用例索引

共100组；任选即可，不要求全部运行。每个文件夹都是一次独立运行。用例名仅为标识，说明列描述本次题目下的内容。

| 程序 | 用例 | 说明 |
| --- | --- | --- |
| lab8_1 | [sample](lab8_1/sample/input.txt) | 题面样例 |
| lab8_1 | [single](lab8_1/single/input.txt) | 单字符与全部删除 |
| lab8_1 | [ties](lab8_1/ties/input.txt) | 删除后与比较串相同 |
| lab8_2 | [sample](lab8_2/sample/input.txt) | 题面样例 |
| lab8_2 | [edge](lab8_2/edge/input.txt) | 100 个元素，逆置整个数组 |
| lab8_2 | [contained](lab8_2/contained/input.txt) | 内部偶数长度区间，两侧元素保留 |
| lab8_1 | [all_zero](lab8_1/all_zero/input.txt) | 全部字符被删除 |
| lab8_1 | [maximum_name](lab8_1/maximum_name/input.txt) | 最长字符串与相等比较 |
| lab8_2 | [touch_point](lab8_2/touch_point/input.txt) | 区间从数组开头起，含零和重复值 |
| lab8_2 | [opposite_corners](lab8_2/opposite_corners/input.txt) | 相邻两个元素，区间到数组末尾 |
| lab8_2 | [equal](lab8_2/equal/input.txt) | 数组只有一个元素 |
| lab8_2 | [negative](lab8_2/negative/input.txt) | 全负数，逆置整个奇数长度数组 |
| lab8_2 | [gap](lab8_2/gap/input.txt) | 数组内的单元素区间，含数值上下界 |
| lab8_1 | [combination_01](lab8_1/combination_01/input.txt) | 随机组合 01 |
| lab8_1 | [combination_02](lab8_1/combination_02/input.txt) | 随机组合 02 |
| lab8_1 | [combination_03](lab8_1/combination_03/input.txt) | 随机组合 03 |
| lab8_1 | [combination_04](lab8_1/combination_04/input.txt) | 随机组合 04 |
| lab8_1 | [combination_05](lab8_1/combination_05/input.txt) | 随机组合 05 |
| lab8_1 | [combination_06](lab8_1/combination_06/input.txt) | 随机组合 06 |
| lab8_1 | [combination_07](lab8_1/combination_07/input.txt) | 随机组合 07 |
| lab8_1 | [combination_08](lab8_1/combination_08/input.txt) | 随机组合 08 |
| lab8_1 | [combination_09](lab8_1/combination_09/input.txt) | 随机组合 09 |
| lab8_1 | [combination_10](lab8_1/combination_10/input.txt) | 随机组合 10 |
| lab8_1 | [combination_11](lab8_1/combination_11/input.txt) | 随机组合 11 |
| lab8_1 | [combination_12](lab8_1/combination_12/input.txt) | 随机组合 12 |
| lab8_1 | [combination_13](lab8_1/combination_13/input.txt) | 随机组合 13 |
| lab8_1 | [combination_14](lab8_1/combination_14/input.txt) | 随机组合 14 |
| lab8_1 | [combination_15](lab8_1/combination_15/input.txt) | 随机组合 15 |
| lab8_1 | [combination_16](lab8_1/combination_16/input.txt) | 随机组合 16 |
| lab8_1 | [combination_17](lab8_1/combination_17/input.txt) | 随机组合 17 |
| lab8_1 | [combination_18](lab8_1/combination_18/input.txt) | 随机组合 18 |
| lab8_1 | [combination_19](lab8_1/combination_19/input.txt) | 随机组合 19 |
| lab8_1 | [combination_20](lab8_1/combination_20/input.txt) | 随机组合 20 |
| lab8_1 | [combination_21](lab8_1/combination_21/input.txt) | 随机组合 21 |
| lab8_1 | [combination_22](lab8_1/combination_22/input.txt) | 随机组合 22 |
| lab8_1 | [combination_23](lab8_1/combination_23/input.txt) | 随机组合 23 |
| lab8_1 | [combination_24](lab8_1/combination_24/input.txt) | 随机组合 24 |
| lab8_1 | [combination_25](lab8_1/combination_25/input.txt) | 随机组合 25 |
| lab8_1 | [combination_26](lab8_1/combination_26/input.txt) | 随机组合 26 |
| lab8_1 | [combination_27](lab8_1/combination_27/input.txt) | 随机组合 27 |
| lab8_1 | [combination_28](lab8_1/combination_28/input.txt) | 随机组合 28 |
| lab8_1 | [combination_29](lab8_1/combination_29/input.txt) | 随机组合 29 |
| lab8_1 | [combination_30](lab8_1/combination_30/input.txt) | 随机组合 30 |
| lab8_1 | [combination_31](lab8_1/combination_31/input.txt) | 随机组合 31 |
| lab8_1 | [combination_32](lab8_1/combination_32/input.txt) | 随机组合 32 |
| lab8_1 | [combination_33](lab8_1/combination_33/input.txt) | 随机组合 33 |
| lab8_1 | [combination_34](lab8_1/combination_34/input.txt) | 随机组合 34 |
| lab8_1 | [combination_35](lab8_1/combination_35/input.txt) | 随机组合 35 |
| lab8_1 | [combination_36](lab8_1/combination_36/input.txt) | 随机组合 36 |
| lab8_1 | [combination_37](lab8_1/combination_37/input.txt) | 随机组合 37 |
| lab8_1 | [combination_38](lab8_1/combination_38/input.txt) | 随机组合 38 |
| lab8_1 | [combination_39](lab8_1/combination_39/input.txt) | 随机组合 39 |
| lab8_1 | [combination_40](lab8_1/combination_40/input.txt) | 随机组合 40 |
| lab8_1 | [combination_41](lab8_1/combination_41/input.txt) | 随机组合 41 |
| lab8_1 | [combination_42](lab8_1/combination_42/input.txt) | 随机组合 42 |
| lab8_1 | [combination_43](lab8_1/combination_43/input.txt) | 随机组合 43 |
| lab8_1 | [combination_44](lab8_1/combination_44/input.txt) | 随机组合 44 |
| lab8_1 | [combination_45](lab8_1/combination_45/input.txt) | 随机组合 45 |
| lab8_2 | [combination_01](lab8_2/combination_01/input.txt) | 随机组合 01 |
| lab8_2 | [combination_02](lab8_2/combination_02/input.txt) | 随机组合 02 |
| lab8_2 | [combination_03](lab8_2/combination_03/input.txt) | 随机组合 03 |
| lab8_2 | [combination_04](lab8_2/combination_04/input.txt) | 随机组合 04 |
| lab8_2 | [combination_05](lab8_2/combination_05/input.txt) | 随机组合 05 |
| lab8_2 | [combination_06](lab8_2/combination_06/input.txt) | 随机组合 06 |
| lab8_2 | [combination_07](lab8_2/combination_07/input.txt) | 随机组合 07 |
| lab8_2 | [combination_08](lab8_2/combination_08/input.txt) | 随机组合 08 |
| lab8_2 | [combination_09](lab8_2/combination_09/input.txt) | 随机组合 09 |
| lab8_2 | [combination_10](lab8_2/combination_10/input.txt) | 随机组合 10 |
| lab8_2 | [combination_11](lab8_2/combination_11/input.txt) | 随机组合 11 |
| lab8_2 | [combination_12](lab8_2/combination_12/input.txt) | 随机组合 12 |
| lab8_2 | [combination_13](lab8_2/combination_13/input.txt) | 随机组合 13 |
| lab8_2 | [combination_14](lab8_2/combination_14/input.txt) | 随机组合 14 |
| lab8_2 | [combination_15](lab8_2/combination_15/input.txt) | 随机组合 15 |
| lab8_2 | [combination_16](lab8_2/combination_16/input.txt) | 随机组合 16 |
| lab8_2 | [combination_17](lab8_2/combination_17/input.txt) | 随机组合 17 |
| lab8_2 | [combination_18](lab8_2/combination_18/input.txt) | 随机组合 18 |
| lab8_2 | [combination_19](lab8_2/combination_19/input.txt) | 随机组合 19 |
| lab8_2 | [combination_20](lab8_2/combination_20/input.txt) | 随机组合 20 |
| lab8_2 | [combination_21](lab8_2/combination_21/input.txt) | 随机组合 21 |
| lab8_2 | [combination_22](lab8_2/combination_22/input.txt) | 随机组合 22 |
| lab8_2 | [combination_23](lab8_2/combination_23/input.txt) | 随机组合 23 |
| lab8_2 | [combination_24](lab8_2/combination_24/input.txt) | 随机组合 24 |
| lab8_2 | [combination_25](lab8_2/combination_25/input.txt) | 随机组合 25 |
| lab8_2 | [combination_26](lab8_2/combination_26/input.txt) | 随机组合 26 |
| lab8_2 | [combination_27](lab8_2/combination_27/input.txt) | 随机组合 27 |
| lab8_2 | [combination_28](lab8_2/combination_28/input.txt) | 随机组合 28 |
| lab8_2 | [combination_29](lab8_2/combination_29/input.txt) | 随机组合 29 |
| lab8_2 | [combination_30](lab8_2/combination_30/input.txt) | 随机组合 30 |
| lab8_2 | [combination_31](lab8_2/combination_31/input.txt) | 随机组合 31 |
| lab8_2 | [combination_32](lab8_2/combination_32/input.txt) | 随机组合 32 |
| lab8_2 | [combination_33](lab8_2/combination_33/input.txt) | 随机组合 33 |
| lab8_2 | [combination_34](lab8_2/combination_34/input.txt) | 随机组合 34 |
| lab8_2 | [combination_35](lab8_2/combination_35/input.txt) | 随机组合 35 |
| lab8_2 | [combination_36](lab8_2/combination_36/input.txt) | 随机组合 36 |
| lab8_2 | [combination_37](lab8_2/combination_37/input.txt) | 随机组合 37 |
| lab8_2 | [combination_38](lab8_2/combination_38/input.txt) | 随机组合 38 |
| lab8_2 | [combination_39](lab8_2/combination_39/input.txt) | 随机组合 39 |
| lab8_2 | [combination_40](lab8_2/combination_40/input.txt) | 随机组合 40 |
| lab8_2 | [combination_41](lab8_2/combination_41/input.txt) | 随机组合 41 |
| lab8_2 | [combination_42](lab8_2/combination_42/input.txt) | 随机组合 42 |
